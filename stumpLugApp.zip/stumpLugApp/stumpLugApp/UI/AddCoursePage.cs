﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stumpLugApp.UI
{
    class AddCoursePage : Page
    {
        public override void OnLoad()
        {
            base.OnLoad();
            Console.WriteLine("Hello World! (From AddCoursePage)");
            Console.ReadKey();
        }
    }
}
